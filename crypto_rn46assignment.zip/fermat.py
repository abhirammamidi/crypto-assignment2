"""
Primality Testing Assignment - Part 2: Fermat Primality Test
Language: Python 3

Name    : Abhiram Mamidi
Roll No : AM.SC.U4CYS25046

Fermat's little theorem: if n is prime and gcd(a, n) = 1, then
    a^(n-1) = 1 (mod n)
So for an odd n > 3 and a base a with 2 <= a <= n-2:
  - if a^(n-1) mod n != 1  ->  n is definitely composite
  - if a^(n-1) mod n == 1  ->  n is only "probably prime" for base a
Some composites (e.g. 341 = 11 * 31 with base 2) also give 1,
so a pass is not a proof of primality.

Only pow(a, e, n) is used for modular exponentiation (allowed).
"""

import math

BASE = 2  # base used for the required test runs


def fermat_test(n, a=BASE, show_steps=False):
    """Return 'Neither', 'Prime', 'Composite' or 'Probably prime (base a)'."""
    # Numbers below 2 are neither prime nor composite
    if n < 2:
        return "Neither"

    # 2 and 3 are handled separately: no base fits 2 <= a <= n-2
    if n in (2, 3):
        return "Prime"

    # Even numbers greater than 2 are composite
    if n % 2 == 0:
        return "Composite"

    # The base must be in the valid range
    if not (2 <= a <= n - 2):
        raise ValueError("base a must satisfy 2 <= a <= n-2")

    # If a shares a factor with n, n cannot be prime
    if math.gcd(a, n) != 1:
        if show_steps:
            print(f"  gcd({a}, {n}) = {math.gcd(a, n)} > 1, so {n} is composite")
        return "Composite"

    if show_steps:
        # Show the powers a^1, a^2, a^4, a^8, ... mod n (repeated squaring)
        print(f"  Compute {a}^{n-1} mod {n} using repeated squaring")
        e, value = 1, a % n
        while e <= n - 1:
            print(f"  {a}^{e} mod {n} = {value}")
            value = (value * value) % n
            e *= 2

    # Main step: a^(n-1) mod n
    result = pow(a, n - 1, n)
    if show_steps:
        print(f"  Result: {a}^{n-1} mod {n} = {result}")

    if result != 1:
        return "Composite"                    # Fermat's theorem fails
    return f"Probably prime (base {a})"        # passes for this base


if __name__ == "__main__":
    # Worked example
    print("Worked example: Fermat test, n = 13, a = 2")
    print("  Conclusion:", fermat_test(13, 2, show_steps=True))

    # A composite that passes (Fermat liar)
    print("\nComposite that passes: n = 341 = 11 * 31, a = 2")
    print("  Conclusion:", fermat_test(341, 2))

    # Required test runs
    print(f"\nRequired test runs (base a = {BASE})")
    print(f"{'Input':<8}{'Fermat'}")
    print("-" * 34)
    for n in [1, 2, 3, 4, 9, 17, 21, 29]:
        print(f"{n:<8}{fermat_test(n)}")

    # Test any number entered by the user
    try:
        user = input("\nEnter an integer to test (or press Enter to quit): ").strip()
        if user:
            print("Result:", fermat_test(int(user), show_steps=True))
    except (EOFError, ValueError):
        pass
