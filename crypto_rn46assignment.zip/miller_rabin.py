"""
Primality Testing Assignment - Part 3: Miller-Rabin Primality Test
Language: Python 3

Name    : Abhiram Mamidi
Roll No : AM.SC.U4CYS25046

Steps for an odd n > 3 and base a with 2 <= a <= n-2:
  1. Write n - 1 = 2^s * d, where d is odd.
  2. Compute x0 = a^d mod n.
     If x0 == 1 or x0 == n-1, n passes for base a.
  3. Otherwise square x up to s-1 times.
     If some square equals n-1, n passes for base a.
  4. If n-1 never appears, n is definitely composite.
A pass means "probably prime for the tested base", not a proof.

Only pow(a, e, n) is used for modular exponentiation (allowed).
"""

BASE = 2  # base used for the required test runs


def miller_rabin(n, a=BASE, show_steps=False):
    """Return 'Neither', 'Prime', 'Composite' or 'Probably prime (base a)'."""
    # Numbers below 2 are neither prime nor composite
    if n < 2:
        return "Neither"

    # 2 and 3 are handled separately: no base fits 2 <= a <= n-2
    if n in (2, 3):
        return "Prime"

    # Even numbers greater than 2 are composite
    if n % 2 == 0:
        return "Composite"

    # The base must be in the valid range
    if not (2 <= a <= n - 2):
        raise ValueError("base a must satisfy 2 <= a <= n-2")

    # Step 1: write n - 1 = 2^s * d with d odd
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    if show_steps:
        print(f"  n - 1 = {n-1} = 2^{s} * {d}  ->  s = {s}, d = {d}")

    # Step 2: initial value x0 = a^d mod n
    x = pow(a, d, n)
    if show_steps:
        print(f"  x0 = {a}^{d} mod {n} = {x}")
    if x == 1 or x == n - 1:
        if show_steps:
            print(f"  x0 is 1 or n-1, so the test passes")
        return f"Probably prime (base {a})"

    # Step 3: square x up to s-1 times, looking for n-1
    for i in range(1, s):
        x = (x * x) % n
        if show_steps:
            print(f"  x{i} = x{i-1}^2 mod {n} = {x}")
        if x == n - 1:
            if show_steps:
                print(f"  Reached n-1 = {n-1}, so the test passes")
            return f"Probably prime (base {a})"
        if x == 1:
            # Reached 1 without passing through n-1: composite
            break

    # Step 4: n-1 never appeared
    if show_steps:
        print(f"  n-1 = {n-1} never appeared, so {n} is composite")
    return "Composite"


if __name__ == "__main__":
    # Worked example
    print("Worked example: Miller-Rabin, n = 17, a = 3")
    print("  Conclusion:", miller_rabin(17, 3, show_steps=True))

    # The Fermat liar 341 is caught by Miller-Rabin
    print("\nComposite that fools Fermat: n = 341 = 11 * 31, a = 2")
    print("  Conclusion:", miller_rabin(341, 2, show_steps=True))

    # Required test runs
    print(f"\nRequired test runs (base a = {BASE})")
    print(f"{'Input':<8}{'Miller-Rabin'}")
    print("-" * 34)
    for n in [1, 2, 3, 4, 9, 17, 21, 29]:
        print(f"{n:<8}{miller_rabin(n)}")

    # Test any number entered by the user
    try:
        user = input("\nEnter an integer to test (or press Enter to quit): ").strip()
        if user:
            print("Result:", miller_rabin(int(user), show_steps=True))
    except (EOFError, ValueError):
        pass
