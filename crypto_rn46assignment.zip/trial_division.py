"""
Primality Testing Assignment - Part 1: Trial Division
Language: Python 3

Name    : Abhiram Mamidi
Roll No : AM.SC.U4CYS25046

Idea: test every possible divisor d from 2 up to floor(sqrt(n)).
If any d divides n, n is composite. If none does, n is prime.
Stopping at sqrt(n) is enough: if n = a * b with both a and b
greater than sqrt(n), then a * b > n, which is impossible.
So any composite n must have a divisor <= sqrt(n).
"""

import math


def trial_division(n, show_steps=False):
    """Return 'Prime', 'Composite' or 'Neither' for the integer n."""
    # Numbers below 2 are neither prime nor composite
    if n < 2:
        return "Neither"

    # 2 and 3 are prime
    if n in (2, 3):
        return "Prime"

    # Even numbers greater than 2 are divisible by 2
    if n % 2 == 0:
        if show_steps:
            print(f"  {n} mod 2 = 0  ->  2 divides {n}")
        return "Composite"

    # Largest divisor we need to test
    limit = math.isqrt(n)
    if show_steps:
        print(f"  sqrt({n}) = {math.sqrt(n):.3f}, so test divisors 2 to {limit}")

    # Test every divisor from 2 to floor(sqrt(n))
    for d in range(2, limit + 1):
        r = n % d                      # remainder of n divided by d
        if show_steps:
            print(f"  {n} mod {d} = {r}")
        if r == 0:                     # d divides n exactly
            if show_steps:
                print(f"  {d} divides {n}, so {n} is composite")
            return "Composite"

    # No divisor found up to sqrt(n)
    if show_steps:
        print(f"  No divisor found up to {limit}, so {n} is prime")
    return "Prime"


if __name__ == "__main__":
    # Worked example
    print("Worked example: Trial division, n = 29")
    print("  Conclusion:", trial_division(29, show_steps=True))

    # Required test runs
    print("\nRequired test runs")
    print(f"{'Input':<8}{'Trial division'}")
    print("-" * 24)
    for n in [1, 2, 3, 4, 9, 17, 21, 29]:
        print(f"{n:<8}{trial_division(n)}")

    # Test any number entered by the user
    try:
        user = input("\nEnter an integer to test (or press Enter to quit): ").strip()
        if user:
            print("Result:", trial_division(int(user), show_steps=True))
    except (EOFError, ValueError):
        pass
